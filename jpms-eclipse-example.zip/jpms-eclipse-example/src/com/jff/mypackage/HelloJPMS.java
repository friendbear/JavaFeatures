package com.jff.mypackage;

public class HelloJPMS {

	public void helloJPMS() {

		System.out.println("Hello JPMS");
	}

}