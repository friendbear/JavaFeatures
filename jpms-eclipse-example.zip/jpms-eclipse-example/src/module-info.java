
module com.jff.mymodule {
	exports com.jff.mypackage;
}